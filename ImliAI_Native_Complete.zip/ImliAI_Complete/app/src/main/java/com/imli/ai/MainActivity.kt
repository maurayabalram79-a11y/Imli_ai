package com.imli.ai

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var speech: SpeechRecognizer
    private lateinit var tts: TextToSpeech
    private lateinit var transcript: TextView
    private lateinit var status: TextView
    private lateinit var mic: Button
    private lateinit var continuous: Button
    private val handler = Handler(Looper.getMainLooper())
    private var listening = false
    private var continuousMode = false
    private var torchOn = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        transcript = findViewById(R.id.transcript)
        status = findViewById(R.id.status)
        mic = findViewById(R.id.micButton)
        continuous = findViewById(R.id.continuousButton)
        tts = TextToSpeech(this, this)
        createSpeechRecognizer()

        mic.setOnClickListener { startListening() }
        continuous.setOnClickListener {
            continuousMode = !continuousMode
            continuous.text = if (continuousMode) "🔁 Continuous Listening: ON" else "🔁 Continuous Listening: OFF"
            if (continuousMode) startListening() else stopListening()
        }
        findViewById<Button>(R.id.accessibilityButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.voiceTestButton).setOnClickListener {
            speak("जी Boss, Imli AI तैयार है। Mic दबाकर command बोलिए।")
        }
        findViewById<Button>(R.id.speechSettingsButton).setOnClickListener {
            try { startActivity(Intent(Settings.ACTION_SPEECH_SETTINGS)) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        }
        ensureAudioPermission()
    }

    private fun ensureAudioPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
    }

    private fun createSpeechRecognizer() {
        if (Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            speech = SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
            status.text = "✅ On-device voice recognition उपलब्ध है"
        } else {
            speech = SpeechRecognizer.createSpeechRecognizer(this)
            status.text = "🎤 Voice recognition ready"
        }
        speech.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { listening = true; status.text = "🎤 Boss, मैं सुन रहा हूँ..." }
            override fun onBeginningOfSpeech() { status.text = "🗣️ बोलिए Boss..." }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { listening = false; status.text = "⏳ Command समझ रहा हूँ..." }
            override fun onError(error: Int) {
                listening = false
                status.text = "⚠️ Voice नहीं समझी। Mic दबाकर फिर बोलिए Boss।"
                if (continuousMode) handler.postDelayed({ startListening() }, 900)
            }
            override fun onResults(results: Bundle?) {
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = list?.firstOrNull { it.isNotBlank() }.orEmpty()
                if (text.isBlank()) {
                    status.text = "Boss, command सुनाई नहीं दी।"
                    if (continuousMode) handler.postDelayed({ startListening() }, 700)
                } else handleCommand(text)
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!partial.isNullOrBlank()) transcript.text = "👂 $partial"
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    private fun startListening() {
        ensureAudioPermission()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        if (listening) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Boss, command बोलिए")
        }
        try { speech.startListening(intent) } catch (_: Exception) { status.text = "⚠️ Mic शुरू नहीं हो पाया।" }
    }

    private fun stopListening() {
        try { speech.stopListening() } catch (_: Exception) {}
        listening = false
    }

    private fun normalize(s: String): String = s.lowercase(Locale.getDefault()).replace(Regex("\\s+"), "")

    private fun handleCommand(raw: String) {
        val c = normalize(raw)
        transcript.text = "🗣️ आप: $raw"
        when {
            c.contains("youtube") || c.contains("यूट्यूब") -> openApp("com.google.android.youtube", "https://www.youtube.com", "YouTube")
            c.contains("chrome") || c.contains("क्रोम") -> openApp("com.android.chrome", "https://www.google.com", "Chrome")
            c.contains("google") || c.contains("गूगल") -> openUrl("https://www.google.com", "Google")
            c.contains("camera") || c.contains("कैमरा") -> speakThenOpen("जी Boss, Camera खोल रहा हूँ।", Intent("android.media.action.IMAGE_CAPTURE"))
            c.contains("phone") || c.contains("फोन") || c.contains("call") || c.contains("कॉल") -> speakThenOpen("जी Boss, Phone खोल रहा हूँ।", Intent(Intent.ACTION_DIAL))
            c.contains("message") || c.contains("मैसेज") || c.contains("sms") -> speakThenOpen("जी Boss, Messages खोल रहा हूँ।", Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING))
            c.contains("maps") || c.contains("मैप") || c.contains("नक्शा") -> openUrl("https://maps.google.com", "Maps")
            c.contains("wifi") || c.contains("वाईफाई") -> speakThenOpen("जी Boss, Wi-Fi settings खोल रहा हूँ।", Intent(Settings.ACTION_WIFI_SETTINGS))
            c.contains("bluetooth") || c.contains("ब्लूटूथ") -> speakThenOpen("जी Boss, Bluetooth settings खोल रहा हूँ।", Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            c.contains("network") || c.contains("नेटवर्क") || c.contains("mobiledata") -> speakThenOpen("जी Boss, Network settings खोल रहा हूँ।", Intent(Settings.ACTION_WIRELESS_SETTINGS))
            c.contains("setting") || c.contains("सेटिंग") -> speakThenOpen("जी Boss, Settings खोल रहा हूँ।", Intent(Settings.ACTION_SETTINGS))
            c.contains("flash") || c.contains("torch") || c.contains("लाइट") || c.contains("टॉर्च") -> toggleTorch()
            c.contains("volume") || c.contains("वॉल्यूम") || c.contains("आवाज") || c.contains("आवाज़") -> adjustVolume(c)
            c.contains("समय") || c.contains("बजे") || c.contains("time") -> tellTime()
            c.contains("तारीख") || c.contains("date") || c.contains("आजकौनसादिन") -> tellDate()
            c.contains("battery") || c.contains("बैटरी") || c.contains("चार्ज") -> tellBattery()
            c == "back" || c.contains("वापस") -> globalBack()
            c == "home" || c.contains("होम") -> globalHome()
            c.contains("ऊपरस्क्रॉल") || c.contains("scrollup") || c.contains("ऊपरजाओ") -> doScroll(false)
            c.contains("नीचेस्क्रॉल") || c.contains("scrolldown") || c.contains("नीचेजाओ") -> doScroll(true)
            c.contains("lock") || c.contains("स्क्रीनलॉक") || c.contains("लॉककरो") -> doLock()
            c.contains("accessibility") || c.contains("एक्सेसिबिलिटी") -> speakThenOpen("जी Boss, Accessibility settings खोल रहा हूँ।", Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            else -> {
                speak("Boss, मैंने सुना: $raw। इस command का action अभी नहीं मिला।")
                if (continuousMode) handler.postDelayed({ startListening() }, 1500)
            }
        }
    }

    private fun openApp(pkg: String, fallback: String, name: String) {
        speak("जी Boss, मैं $name खोल रहा हूँ।")
        handler.postDelayed({
            try {
                val launch = packageManager.getLaunchIntentForPackage(pkg)
                if (launch != null) startActivity(launch) else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(fallback)))
                handler.postDelayed({ speak("Boss, $name open हो गया।"); resumeContinuous() }, 800)
            } catch (_: Exception) { speak("Boss, $name खोलने में दिक्कत हुई।") }
        }, 650)
    }

    private fun openUrl(url: String, name: String) {
        speak("जी Boss, $name खोल रहा हूँ।")
        handler.postDelayed({
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))); handler.postDelayed({ speak("Boss, $name open हो गया।"); resumeContinuous() }, 800) }
            catch (_: Exception) { speak("Boss, $name खोलने में दिक्कत हुई।") }
        }, 650)
    }

    private fun speakThenOpen(message: String, intent: Intent) {
        speak(message)
        handler.postDelayed({
            try { startActivity(intent); handler.postDelayed({ speak("Boss, काम हो गया।"); resumeContinuous() }, 700) }
            catch (_: Exception) { speak("Boss, यह काम पूरा नहीं हो पाया।") }
        }, 650)
    }

    private fun resumeContinuous() { if (continuousMode) handler.postDelayed({ startListening() }, 900) }

    private fun tellTime() { speak("जी Boss, अभी समय ${SimpleDateFormat("hh:mm a", Locale("hi", "IN")).format(Date())} है।"); resumeContinuous() }
    private fun tellDate() { speak("जी Boss, आज ${SimpleDateFormat("dd MMMM yyyy", Locale("hi", "IN")).format(Date())} है।"); resumeContinuous() }

    private fun tellBattery() {
        val intent = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra("level", -1) ?: -1
        speak(if (level >= 0) "जी Boss, battery $level percent है।" else "Boss, battery status नहीं मिल पाया।")
        resumeContinuous()
    }

    private fun adjustVolume(c: String) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val down = c.contains("कम") || c.contains("घटा") || c.contains("down")
        val mute = c.contains("mute") || c.contains("म्यूट")
        if (mute) am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
        else am.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (down) AudioManager.ADJUST_LOWER else AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
        speak(if (mute) "Boss, media volume mute कर दिया।" else if (down) "Boss, volume कम कर दिया।" else "Boss, volume बढ़ा दिया।")
        resumeContinuous()
    }

    private fun toggleTorch() {
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            if (id == null) { speak("Boss, flashlight उपलब्ध नहीं है।"); return }
            torchOn = !torchOn
            cm.setTorchMode(id, torchOn)
            speak(if (torchOn) "जी Boss, flashlight ON कर दी।" else "जी Boss, flashlight OFF कर दी।")
            resumeContinuous()
        } catch (_: Exception) { speak("Boss, flashlight control नहीं हो पाया।") }
    }

    private fun globalBack() { speak("जी Boss, वापस जा रहा हूँ।"); if (ImliAccessibilityService.instance?.back() != true) onBackPressedDispatcher.onBackPressed(); resumeContinuous() }
    private fun globalHome() { speak("जी Boss, Home पर जा रहा हूँ।"); ImliAccessibilityService.instance?.home(); resumeContinuous() }
    private fun doScroll(forward: Boolean) { val ok = ImliAccessibilityService.instance?.scroll(forward) == true; speak(if (ok) "Boss, scroll कर दिया।" else "Boss, Accessibility Service ON करनी होगी।"); resumeContinuous() }
    private fun doLock() { val ok = ImliAccessibilityService.instance?.lockScreen() == true; speak(if (ok) "Boss, screen lock कर दी।" else "Boss, Accessibility Service ON करनी होगी।"); resumeContinuous() }

    private fun speak(text: String) {
        status.text = text
        if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "imli_${System.currentTimeMillis()}")
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            val r = tts.setLanguage(Locale("hi", "IN"))
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) tts.language = Locale("en", "IN")
            tts.setSpeechRate(0.95f)
        }
    }

    override fun onDestroy() {
        try { speech.destroy() } catch (_: Exception) {}
        try { tts.stop(); tts.shutdown() } catch (_: Exception) {}
        super.onDestroy()
    }
}
