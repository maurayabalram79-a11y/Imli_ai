# 🍋 Imli AI — Native Android Voice Assistant

यह **Native Android** project है, Web APK नहीं। इसका लक्ष्य है: **Mic दबाओ → Hindi command बोलो → Imli action करे → Boss को voice confirmation दे।**

## जरूरी बात
- Android Studio में project खोलें और Gradle Sync करें।
- फोन में **Google/Android speech recognition** और Hindi language support उपलब्ध होना चाहिए।
- Android 12+ में अगर on-device Hindi recognizer/model उपलब्ध है, Imli उसे पहले इस्तेमाल करता है। इससे supported commands बिना mobile data चल सकते हैं।
- अगर on-device recognizer उपलब्ध नहीं है, Android का normal speech recognizer इस्तेमाल होगा, जिसमें Internet की जरूरत हो सकती है।
- YouTube/Google/Maps का online content बिना Internet नहीं चलेगा।
- Back/Home/Scroll/Lock जैसी system actions के लिए app में **Accessibility Service ON** करना होगा।

## पहला test
1. APK install करें।
2. Microphone permission Allow करें।
3. App खोलें।
4. **🎤 BOSS, SUNO** दबाएँ।
5. साफ बोलें: **"YouTube खोलो"**।
6. Imli बोलेगा: **"जी Boss, मैं YouTube खोल रहा हूँ।"** और YouTube launch करेगा।
7. फिर बोलेगा: **"Boss, YouTube open हो गया।"**

## उपलब्ध commands
YouTube, Chrome, Google, Camera, Phone, Messages, Maps, Wi-Fi settings, Bluetooth settings, Network settings, Settings, Flashlight, Volume, Time, Date, Battery, Back, Home, Scroll Up/Down, Screen Lock, Accessibility settings.

## Android limitation
Normal Android app protected settings जैसे सीधे Mobile Data ON/OFF या phone power-off को हर device पर silently नहीं कर सकती। Accessibility से भी केवल Android द्वारा अनुमति वाले UI/system actions किए जा सकते हैं।
